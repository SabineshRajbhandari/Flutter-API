import 'package:flutter/material.dart';
import 'package:statement/404.dart';
import 'package:statement/post_screen.dart';

void main() {
  runApp(StatementM());
}

class StatementM extends StatelessWidget {
  const StatementM({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: '/',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (context) => PostScreen());
          default:
            return MaterialPageRoute(builder: (context) => NotFound());
        }
      },
    );
  }
}
